﻿using static VoidTemp.Utilities.GunTemplate;
using static VoidTemp.Utilities.Variables;
using static VoidTemp.Utilities.ColorLib;
using static VoidTemp.Mods.Categories.Move;
using static VoidTemp.Mods.Categories.Playerr;
using static VoidTemp.Mods.Categories.Room;
using static VoidTemp.Mods.Categories.Settings;
using static VoidTemp.Menu.ButtonHandler;
using static VoidTemp.Menu.Optimizations;
using static VoidTemp.Menu.Optimizations.ResourceLoader;
using static VoidTemp.Menu.Main;
using UnityEngine;
using Fusion;
using System;
using ExitGames.Client.Photon;
using Photon.Pun;
using System.Collections.Generic;
using VoidTemp.Utilities;
using VoidTemp.Mods.Categories;
using Unity.Mathematics;

namespace VoidTemp.Mods
{
    public enum Category
    {
        // Starting Page
        Home,

        // Mod Categories
        Settings,
        Room,
        Player,
        Move,
        Visuals,
        Creds,
    }
    public class ModButtons
    {
        public static Button[] buttons =
        {
            #region Starting Page
            new Button("Settings", Category.Home, false, false, ()=>ChangePage(Category.Settings)),
            new Button("Room", Category.Home, false, false, ()=>ChangePage(Category.Room)),
            new Button("Movement", Category.Home, false, false, ()=>ChangePage(Category.Move)),
            new Button("Player", Category.Home, false, false, ()=>ChangePage(Category.Player)),
            new Button("Visual", Category.Home, false, false, ()=>ChangePage(Category.Visuals)),
            new Button("Creds", Category.Home, false, false, ()=>ChangePage(Category.Creds)),
            #endregion
            #region HomeButtons
            //By Putting the home button here it will be at the top of every category
            new Button("Return", Category.Settings, false, false, ()=>ChangePage(Category.Home)),
            new Button("Return", Category.Room, false, false, ()=>ChangePage(Category.Home)),
            new Button("Return", Category.Move, false, false, ()=>ChangePage(Category.Home)),
            new Button("Return", Category.Player, false, false, ()=>ChangePage(Category.Home)),
            new Button("Return", Category.Visuals, false, false, ()=>ChangePage(Category.Home)),
            new Button("Return", Category.Creds, false, false, ()=>ChangePage(Category.Home)),
            #endregion
            #region Settings
            new Button("Disable All Mods", Category.Settings, false, false, ()=>DisableAllMods()),
            new Button("Switch Hands", Category.Settings, true, false, ()=>SwitchHands(true), ()=>SwitchHands(false)),
            new Button("Disconnect Button", Category.Settings, true, true, ()=>ToggleDisconnectButton(true), ()=>ToggleDisconnectButton(false)),
            new Button("Toggle Notifications", Category.Settings, true, true, ()=>ToggleNotifications(true), ()=>ToggleNotifications(false)),
            new Button("Clear Notifications", Category.Settings, false, false, ()=>ClearNotifications()),
            new Button("Change Layout", Category.Settings, false, false, ()=> ChangeMenuLayout()),
            new Button("Refresh Menu", Category.Settings, false, false, ()=> RefreshMenu()),
            #endregion

            #region Room
            new Button("Quit Game", Category.Room, true, false, ()=>QuitGTAG()),
            new Button("Join Random", Category.Room, false, false, ()=>JoinRandomPublic()),
            new Button("Disconnect", Category.Room, false, false, ()=>Disconnect()),
            new Button("Primary Disconnect", Category.Room, true, false, ()=>PrimaryDisconnect()),
            new Button("Check If Master", Category.Room, false, false, ()=>IsMasterCheck()),
            #endregion

            #region Movement
            new Button("Toggleable Placeholder", Category.Move, true, false, ()=>Placeholder()),
            new Button("Enabled Placeholder", Category.Move, true, true, ()=>Placeholder()),
            new Button("Placeholder", Category.Move, false, false, ()=>Placeholder()),
            #endregion

            #region Player
            new Button("Toggleable Placeholder", Category.Player, true, false, ()=>Placeholder()),
            new Button("Enabled Placeholder", Category.Player, true, true, ()=>Placeholder()),
            new Button("Placeholder", Category.Player, false, false, ()=>Placeholder()),
            #endregion

            #region Visuals
            new Button("Toggleable Placeholder", Category.Visuals, true, false, ()=>Placeholder()),
            new Button("Enabled Placeholder", Category.Visuals, true, true, ()=>Placeholder()),
            new Button("Placeholder", Category.Visuals, false, false, ()=>Placeholder()),
            #endregion

            #region Credits
            new Button("Menu Credits:", Category.Creds, false, false, ()=>Placeholder()),
            new Button("Psi Template", Category.Creds, false, false, ()=>Placeholder()), // Template you are using
            new Button("NxO Template", Category.Creds, false, false, ()=>Placeholder()), // Template Psi Temp is based off
            new Button("Join The Discord!", Category.Creds, false, false, ()=>Discord()),
            #endregion
        };
    }
}
