﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static VoidTemp.Utilities.Variables;
using static VoidTemp.Utilities.ColorLib;
using static VoidTemp.Mods.Categories.Settings;
using static VoidTemp.Menu.Main;
using Photon.Pun;
using Object = UnityEngine.Object;
using System.Linq;
using Photon.Realtime;
using UnityEngine.InputSystem.Controls;
using System.Drawing;
using System.Xml.Linq;
using VoidTemp.Utilities;


namespace VoidTemp.Mods.Categories
{
    public class Visuals 
    {
        
    }
}

