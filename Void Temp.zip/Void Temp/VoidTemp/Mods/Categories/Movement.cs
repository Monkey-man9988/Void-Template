﻿using System;
using System.Collections.Generic;
using System.Text;
using static VoidTemp.Utilities.GunTemplate;
using static VoidTemp.Menu.Main;
using static VoidTemp.Utilities.Variables;
using static VoidTemp.Utilities.ColorLib;
using static VoidTemp.Utilities.RigManager;
using static VoidTemp.Menu.ButtonHandler;
using static VoidTemp.Mods.ModButtons;
using static VoidTemp.Mods.Categories.Settings;
using UnityEngine;
using Valve.VR;
using System.Reflection;
using BepInEx;
using Photon.Voice;
using VoidTemp.Utilities;
using VoidTemp.Utilities;

namespace VoidTemp.Mods.Categories
{
    public class Move
    {

    }
}
