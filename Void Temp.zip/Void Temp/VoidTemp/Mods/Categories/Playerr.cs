﻿using System;
using System.Collections.Generic;
using System.Text;
using static VoidTemp.Utilities.GunTemplate;
using static VoidTemp.Utilities.ColorLib;
using static VoidTemp.Utilities.Variables;
using static VoidTemp.Menu.Main;
using static VoidTemp.Mods.Categories.Settings;
using UnityEngine;
using UnityEngine.InputSystem;
using VoidTemp.Utilities;
using UnityEngine.XR;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR.Interaction.Toolkit;
using GorillaNetworking;
using VoidTemp.Utilities.Patches;
using VoidTemp.Menu;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using HarmonyLib;
using BepInEx;
using VoidTemp.Utilities;

namespace VoidTemp.Mods.Categories
{
    public class Playerr
    {
       
    }
}
