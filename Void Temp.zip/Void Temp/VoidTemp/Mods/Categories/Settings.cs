﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;
using Object = UnityEngine.Object;
using static VoidTemp.Utilities.ColorLib;
using static VoidTemp.Utilities.Variables;
using static VoidTemp.Menu.Main;
using static VoidTemp.Menu.ButtonHandler;
using static VoidTemp.Menu.Optimizations;
using VoidTemp.Utilities;
using VoidTemp.Menu;
using static VoidTemp.Mods.Categories.Move;
using static VoidTemp.Utilities.Patches.OtherPatches;
using static VoidTemp.Utilities.GunTemplate;
using System.Linq;
using Oculus.Platform;
using Photon.Pun;

namespace VoidTemp.Mods.Categories
{
    public class Settings
    {
        public static void SwitchHands(bool setActive)
        {
            rightHandedMenu = setActive;
        }

        public static void ClearNotifications()
        {
            NotificationLib.ClearAllNotifications();
        }

        public static void ToggleNotifications(bool setActive)
        {
            toggleNotifications = setActive;
        }

        public static void ToggleDisconnectButton(bool setActive)
        {
            toggledisconnectButton = setActive;
        }
        public static void GunExample()
        {
            GunTemplate.StartBothGuns(() =>
            {// method when active

            }, false); // lockon
            {// method when not active

            }
        }
        public static void Discord()
        {
            UnityEngine.Application.OpenURL("REPLACE WITH YOUR OWN LINK");
        }

    }
}
