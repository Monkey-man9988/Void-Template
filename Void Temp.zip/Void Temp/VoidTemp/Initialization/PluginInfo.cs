﻿namespace VoidTemp.Initialization
{
    public class PluginInfo
    {
        public const string menuGUID = "com.VoidTemp.VoidTemp.org";
        public const string menuName = "Void Temp";
        public const string menuVersion = "1.0";
    }
}
